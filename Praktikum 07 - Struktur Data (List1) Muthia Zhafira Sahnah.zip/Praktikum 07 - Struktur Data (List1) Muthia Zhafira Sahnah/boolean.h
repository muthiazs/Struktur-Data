#ifndef boolean_H
#define boolean_H 
/* File : boolean.h */
/* NIM & Nama : 24060122130071*/
/* Tanggal : 4 NOVEMBER 2023 */

//type boolean macro bahasa C, false=0, true=1 
#define false 0
#define true  1
#define boolean unsigned char 

#endif