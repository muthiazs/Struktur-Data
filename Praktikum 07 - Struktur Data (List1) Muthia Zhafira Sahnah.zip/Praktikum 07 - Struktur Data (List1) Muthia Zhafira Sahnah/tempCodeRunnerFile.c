printf("\n------MENAMBAHKAN ELEMEN A SETELAH Y-----\n");
  InsertVAfter(&LL ,'Y','A');
  PrintList(LL);